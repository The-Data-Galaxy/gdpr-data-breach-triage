# Manifest

Candidate v0.1.2. Exact file membership and SHA-256 values are in CHECKSUMS.txt, which covers every other payload file in this tree. It excludes itself to avoid a circular hash. The downloadable ZIP is placed beside this tree; its hash is in the adjacent SHA256SUMS.txt and the development readiness report.

Installable directory: gdpr-data-breach-triage/. Ten runtime files plus LICENSE and THIRD_PARTY_NOTICES.md. Runtime is copied from the final development candidate without transformations.

Public auxiliary files: README.md, INSTALL.md, LICENSE, THIRD_PARTY_NOTICES.md, RELEASE_NOTES.md, VALIDATION.md, MANIFEST.md, CHECKSUMS.txt, examples/ransomware-intake.md.

Excluded: development governance, private feedback, internal work items, historical benchmark inputs/expected answers and scoring files, local install paths, caches, credentials and real incident materials. The included demonstration is synthetic. The official EDPB DOCX is the only bundled binary.
